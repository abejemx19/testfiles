#include <iostream>

using namespace std;

int main()
{
   float num1, num2;
   char operation;
   cout<<"Calculator Apps";
   cin>>num1>>operation>>num2;




}

