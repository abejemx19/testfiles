

#include <iostream>

using namespace std;

int main()
{

class Time {
private:
   void setTime(int, int, int); // set hour, minute and second
   std::string toUniversalString() const; // 24-hour time format string
   std::string toStandardString() const; // 12-hour time format string}



  int a = 4;
  int b = 14;
  int c = b/a;

  cout<<b%a<<endl;

}
