#include <iostream>
#include <cstdlib>

using namespace std;

int main()
{
    rand();
}